from setuptools import setup

setup(
        name='ACRE_Tool',
        version='0.1',
        description='A tool for reading',
        author='Joshua Collado',
        author_email='joshua.colladojh@gmail.com',
        packages=[],
        install_requires=[],
        )
